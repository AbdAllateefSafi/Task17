﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WebApplicationTask17.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Email { get; set; }
        public double Salary { get; set; }
    }
}
